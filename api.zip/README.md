# Inspirehub ecommerce api

Steps to run this project:

1. Run `npm i` command
2. Setup database settings inside `ormconfig.json` file
3. Run `npm start` command
4. If you have `nodemon` installed run `npm run start:dev`
